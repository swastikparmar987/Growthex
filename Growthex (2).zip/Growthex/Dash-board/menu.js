let menu = document.getElementById('btn');                                                                                 
let sidebar = document.querySelector('.sidebar');                                                                                                                                                                      
let subsiLogo = document.querySelector('.subsiLogo');                
let graph = document.querySelector('.graph');                
let account = document.querySelector('.account');                
menu.onclick = function(){
    sidebar.classList.toggle("active");
    subsiLogo.classList.toggle("active");
    graph.classList.toggle("active");
    account.classList.toggle("active");

}
